﻿using TaskManagerClient.Models;

namespace TaskManagerClient.Services
{
    public interface ITaskApiService
    {
        Task<List<TaskItem>> GetAllAsync();
        Task<TaskItem?> GetByIdAsync(int id);
        Task<(bool Success, string? Error)> CreateAsync(TaskItem task);
        Task<(bool Success, string? Error)> UpdateAsync(TaskItem task);
        Task<(bool Success, string? Error)> DeleteAsync(int id);
    }
}