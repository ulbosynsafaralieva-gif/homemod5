﻿using System.Net.Http.Json;
using TaskManagerClient.Models;

namespace TaskManagerClient.Services
{
    public class TaskApiService : ITaskApiService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public TaskApiService(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<List<TaskItem>> GetAllAsync()
        {
            var client = _httpClientFactory.CreateClient("TaskApi");
            var response = await client.GetAsync("api/tasks");

            if (!response.IsSuccessStatusCode)
                return new List<TaskItem>();

            var tasks = await response.Content.ReadFromJsonAsync<List<TaskItem>>();
            return tasks ?? new List<TaskItem>();
        }

        public async Task<TaskItem?> GetByIdAsync(int id)
        {
            var client = _httpClientFactory.CreateClient("TaskApi");
            var response = await client.GetAsync($"api/tasks/{id}");

            if (!response.IsSuccessStatusCode)
                return null;

            return await response.Content.ReadFromJsonAsync<TaskItem>();
        }

        public async Task<(bool Success, string? Error)> CreateAsync(TaskItem task)
        {
            var client = _httpClientFactory.CreateClient("TaskApi");
            var response = await client.PostAsJsonAsync("api/tasks", task);

            if (response.IsSuccessStatusCode)
                return (true, null);

            return (false, BuildErrorMessage(response.StatusCode));
        }

        public async Task<(bool Success, string? Error)> UpdateAsync(TaskItem task)
        {
            var client = _httpClientFactory.CreateClient("TaskApi");
            var response = await client.PutAsJsonAsync($"api/tasks/{task.Id}", task);

            if (response.IsSuccessStatusCode)
                return (true, null);

            return (false, BuildErrorMessage(response.StatusCode));
        }

        public async Task<(bool Success, string? Error)> DeleteAsync(int id)
        {
            var client = _httpClientFactory.CreateClient("TaskApi");
            var response = await client.DeleteAsync($"api/tasks/{id}");

            if (response.IsSuccessStatusCode)
                return (true, null);

            return (false, BuildErrorMessage(response.StatusCode));
        }

        private static string BuildErrorMessage(System.Net.HttpStatusCode statusCode)
        {
            return statusCode switch
            {
                System.Net.HttpStatusCode.BadRequest => "Некорректные данные задачи.",
                System.Net.HttpStatusCode.NotFound => "Задача не найдена.",
                System.Net.HttpStatusCode.InternalServerError => "Внутренняя ошибка сервера. Попробуйте позже.",
                _ => $"Непредвиденная ошибка. Код: {(int)statusCode}"
            };
        }
    }
}