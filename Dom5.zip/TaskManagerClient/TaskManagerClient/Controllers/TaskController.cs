﻿using Microsoft.AspNetCore.Mvc;
using TaskManagerClient.Models;
using TaskManagerClient.Services;

namespace TaskManagerClient.Controllers
{
    public class TaskController : Controller
    {
        private readonly ITaskApiService _apiService;

        public TaskController(ITaskApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            var tasks = await _apiService.GetAllAsync();
            return View(tasks);
        }

        public async Task<IActionResult> Details(int id)
        {
            var task = await _apiService.GetByIdAsync(id);

            if (task == null)
            {
                ViewBag.ErrorMessage = "Задача не найдена.";
                return View("NotFoundTask");
            }

            return View(task);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(TaskItem task)
        {
            var (success, error) = await _apiService.CreateAsync(task);

            if (!success)
            {
                ModelState.AddModelError(string.Empty, error ?? "Не удалось создать задачу.");
                return View(task);
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var task = await _apiService.GetByIdAsync(id);

            if (task == null)
            {
                ViewBag.ErrorMessage = "Задача не найдена.";
                return View("NotFoundTask");
            }

            return View(task);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, TaskItem task)
        {
            task.Id = id;
            var (success, error) = await _apiService.UpdateAsync(task);

            if (!success)
            {
                ModelState.AddModelError(string.Empty, error ?? "Не удалось изменить задачу.");
                return View(task);
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var task = await _apiService.GetByIdAsync(id);

            if (task == null)
            {
                ViewBag.ErrorMessage = "Задача не найдена.";
                return View("NotFoundTask");
            }

            return View(task);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _apiService.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}