﻿using Microsoft.AspNetCore.Mvc;
using TaskApi.Models;

namespace TaskApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private static List<TaskItem> tasks = new()
        {
            new TaskItem { Id = 1, Title = "Изучить HttpClient", Description = "Разобраться с IHttpClientFactory", IsCompleted = true },
            new TaskItem { Id = 2, Title = "Реализовать Web API", Description = "Создать CRUD-контроллер для задач", IsCompleted = false },
            new TaskItem { Id = 3, Title = "Изучить PATCH", Description = "Понять разницу между PUT и PATCH", IsCompleted = false }
        };

        [HttpGet]
        public ActionResult<List<TaskItem>> GetAll()
        {
            return Ok(tasks);
        }

        [HttpGet("{id}")]
        public ActionResult<TaskItem> GetById(int id)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();
            return Ok(task);
        }

        [HttpPost]
        public ActionResult<TaskItem> Create(TaskItem newTask)
        {
            if (newTask == null || string.IsNullOrWhiteSpace(newTask.Title))
                return BadRequest();

            newTask.Id = tasks.Any() ? tasks.Max(t => t.Id) + 1 : 1;
            tasks.Add(newTask);
            return CreatedAtAction(nameof(GetById), new { id = newTask.Id }, newTask);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, TaskItem updated)
        {
            if (updated == null || string.IsNullOrWhiteSpace(updated.Title))
                return BadRequest();

            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();

            task.Title = updated.Title;
            task.Description = updated.Description;
            task.IsCompleted = updated.IsCompleted;

            return Ok(task);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();

            tasks.Remove(task);
            return Ok();
        }
    }
}